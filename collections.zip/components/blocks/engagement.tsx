"use client";
import { tinaField } from "tinacms/dist/react";
import { TinaMarkdown } from "tinacms/dist/rich-text";

export const EngagementSection = (props) => {
  return (
    <section className="bg-gradient-to-r from-primary to-red-700 py-16 md:py-24 section-illumination">
      <div className="container mx-auto px-6 md:px-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="reveal">
            <h2 data-tina-field={tinaField(props, "heading")} className="text-3xl md:text-4xl font-bold mb-6 text-white text-center md:text-left">
              <TinaMarkdown content={props.heading} />
            </h2>
          </div>
          <div className="reveal">
            <div data-tina-field={tinaField(props, "text")} className="text-white text-lg mb-6">
              <TinaMarkdown content={props.text} />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
