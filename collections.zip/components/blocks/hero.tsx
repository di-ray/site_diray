"use client";
import { motion } from "framer-motion";
import { tinaField } from "tinacms/dist/react";
import { TinaMarkdown } from "tinacms/dist/rich-text";
import CTAButton from "@/components/ui/cta-button"; // Assumindo que este componente será criado/copiado

export const HeroSection = (props) => {
  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } },
  };

  return (
    <section className="relative architecture-bg min-h-screen flex items-center py-32 md:py-48">
      <div className="container mx-auto px-6 md:px-8 relative z-10">
        <div className="max-w-2xl">
          <motion.h1
            data-tina-field={tinaField(props, "heading")}
            className="text-6xl md:text-7xl lg:text-7xl font-black tracking-tight mb-10 text-white font-poppins"
            variants={itemVariants}
          >
            <TinaMarkdown content={props.heading} />
          </motion.h1>
          
          <p data-tina-field={tinaField(props, "subheading")} className="text-lg md:text-xl mb-8 text-white">
            {props.subheading}
          </p>

          <div className="mt-8">
            <CTAButton href={props.buttonLink} variant="primary" size="lg" showArrow>
              <span data-tina-field={tinaField(props, "buttonText")}>
                {props.buttonText}
              </span>
            </CTAButton>
          </div>
        </div>
      </div>
    </section>
  );
};
