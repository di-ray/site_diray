"use client";
import { tinaField } from "tinacms/dist/react";
import ContactForm from "@/components/contact-form"; // Assumindo que este componente será criado/copiado

export const ContactSection = (props) => {
  return (
    <section id="contato" className="py-20 md:py-32 architecture-bg">
      <div className="container mx-auto px-6 md:px-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <div className="reveal">
            <h2 data-tina-field={tinaField(props, "heading")} className="text-3xl md:text-4xl font-bold mb-6 text-white">
              {props.heading}
            </h2>
            <p data-tina-field={tinaField(props, "subheading")} className="text-lg mb-8 text-white/80">
              {props.subheading}
            </p>
            {/* Informações de contato (Whatsapp, E-mail) podem ser gerenciadas globalmente ou aqui */}
          </div>
          <div className="bg-dark/50 rounded-lg border border-primary/20 p-8 hover:border-primary/50 transition-all duration-300 reveal">
            <ContactForm />
          </div>
        </div>
      </div>
    </section>
  );
};
