"use client";
import { tinaField } from "tinacms/dist/react";
import { TinaMarkdown } from "tinacms/dist/rich-text";
import Image from "next/image";

export const AboutSection = (props) => {
  return (
    <section id="sobre" className="py-20 md:py-32 architecture-bg">
      <div className="container mx-auto px-6 md:px-8 relative z-10">
        <h2 data-tina-field={tinaField(props, "heading")} className="text-4xl md:text-5xl font-bold mb-12 text-center reveal text-white">
          <TinaMarkdown content={props.heading} />
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center max-w-6xl mx-auto">
          <div className="flex justify-center reveal">
            <div className="relative">
              <Image
                data-tina-field={tinaField(props, "founderImage")}
                src={props.founderImage || "/placeholder.png"}
                alt={props.founderName || "Fundador"}
                width={400}
                height={400}
                className="rounded-lg shadow-lg transform hover:scale-105 transition-all duration-500"
              />
              <div className="text-center mt-4">
                <h3 data-tina-field={tinaField(props, "founderName")} className="text-2xl font-bold text-white">{props.founderName}</h3>
                <p data-tina-field={tinaField(props, "founderTitle")} className="text-white/80">{props.founderTitle}</p>
              </div>
            </div>
          </div>
          <div className="reveal">
            <div data-tina-field={tinaField(props, "biography")} className="text-white text-lg mb-6">
              <TinaMarkdown content={props.biography} />
            </div>
            <div className="w-full flex justify-center items-center">
              <Image
                data-tina-field={tinaField(props, "clientLogosImage")}
                alt="Client Logos"
                loading="lazy"
                width="600"
                height="50"
                src={props.clientLogosImage || "/placeholder.png"}
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
