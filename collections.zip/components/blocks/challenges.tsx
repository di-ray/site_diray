"use client";
import { tinaField } from "tinacms/dist/react";
import { TinaMarkdown } from "tinacms/dist/rich-text";

export const ChallengesSection = (props) => {
  return (
    <section className="bg-dark py-16 md:py-24 section-illumination-red">
      <div className="container mx-auto px-6 md:px-8 relative z-10">
        <h2 data-tina-field={tinaField(props, "heading")} className="text-4xl md:text-5xl font-bold mb-12 text-white text-center reveal">
          {props.heading}
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {props.cards?.map((card, i) => (
            <div key={i} data-tina-field={tinaField(card)} className="bg-gradient-to-r from-primary to-red-400 p-8 rounded-lg border border-primary/30 hover:border-primary transition-all duration-300 reveal">
              <div className="flex flex-col items-center mb-6">
                {/* O ícone SVG será mantido estático por enquanto para simplificar */}
                <h3 data-tina-field={tinaField(card, "title")} className="text-2xl font-bold text-white">{card.title}</h3>
              </div>
              <div data-tina-field={tinaField(card, "content")} className="text-white text-center font-medium">
                <TinaMarkdown content={card.content} />
              </div>
              <div className="mt-6 text-center">
                <p data-tina-field={tinaField(card, "resultText")} className="text-white font-medium">
                  {card.resultText}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
