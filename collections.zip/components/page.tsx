"use client";

import { PageQuery } from "../tina/__generated__/types";
import { tinaField, useTina } from "tinacms/dist/react";
import { TinaMarkdown } from "tinacms/dist/rich-text";

import { HeroSection } from "./blocks/hero";
import { EngagementSection } from "./blocks/engagement";
import { ChallengesSection } from "./blocks/challenges";
import { AboutSection } from "./blocks/about";
import { ContactSection } from "./blocks/contact";

const components = {
  hero: HeroSection,
  engagement: EngagementSection,
  challenges: ChallengesSection,
  about: AboutSection,
  contact: ContactSection,
};

export function Page(props: {
  data: PageQuery;
  variables: object;
  query: string;
}) {
  const { data } = useTina(props);

  // Add error handling for missing data
  if (!data?.page) {
    return (
      <main className="container mx-auto px-6 py-20">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-red-600 mb-4">Erro: Página não encontrada</h1>
          <p className="text-gray-600">Os dados da página não puderam ser carregados.</p>
        </div>
      </main>
    );
  }

  return (
    <main>
      <h1 data-tina-field={tinaField(data.page, "title")} className="text-3xl font-bold text-center py-4">
        {data.page.title}
      </h1>
      {data.page.blocks?.map((block, i) => {
        if (!block || !block.__typename) {
          return null;
        }
        const blockName = block.__typename.replace('PageBlocks', '').toLowerCase();
        const Component = components[blockName];
        if (Component) {
          return (
            <div key={i} data-tina-field={tinaField(block)}>
              <Component {...block} />
            </div>
          );
        }
        // Log warning for missing components
        console.warn(`Component not found for block type: ${blockName}`);
        return null;
      })}
    </main>
  );
}
